package com.example.open_fashion

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
